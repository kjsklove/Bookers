class Book < ApplicationRecord
  enum genre: { novel: 0, bussiness: 1, technology: 2, hobby: 3, commic: 4, magazine: 5, other: 99 }
  enum media: { paper: 0, kindle: 1, epub: 2, pdf: 3}
  
  validates :title, presence: true
  validates :body, presence: true
end
